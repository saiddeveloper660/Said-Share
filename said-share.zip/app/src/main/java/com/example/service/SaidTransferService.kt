package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class SaidTransferService : Service {

    constructor() : super()

    companion object {
        const val CHANNEL_ID = "said_share_transfers"
        const val NOTIFICATION_ID = 8765

        const val ACTION_START = "com.example.service.START"
        const val ACTION_STOP = "com.example.service.STOP"
        const val ACTION_UPDATE_PROGRESS = "com.example.service.UPDATE_PROGRESS"

        const val EXTRA_STATUS = "extra_status"
        const val EXTRA_PROGRESS = "extra_progress"

        fun startService(context: Context, status: String = "Ready to receive") {
            val intent = Intent(context, SaidTransferService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_STATUS, status)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun updateProgress(context: Context, status: String, progressPercent: Int) {
            val intent = Intent(context, SaidTransferService::class.java).apply {
                action = ACTION_UPDATE_PROGRESS
                putExtra(EXTRA_STATUS, status)
                putExtra(EXTRA_PROGRESS, progressPercent)
            }
            context.startService(intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, SaidTransferService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_UPDATE_PROGRESS -> {
                val status = intent.getStringExtra(EXTRA_STATUS) ?: "Transferring..."
                val progress = intent.getIntExtra(EXTRA_PROGRESS, -1)
                updateNotification(status, progress)
            }
            else -> {
                val status = intent?.getStringExtra(EXTRA_STATUS) ?: "Said Share active on local Wi-Fi"
                val notification = buildNotification(status, -1)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Said Share Transfers",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active local Wi-Fi file transfers"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: String, progress: Int): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Said Share")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentIntent(pendingIntent)
            .setOngoing(true)

        if (progress in 0..100) {
            builder.setProgress(100, progress, false)
        } else if (progress == -2) {
            builder.setProgress(0, 0, true)
        }

        return builder.build()
    }

    private fun updateNotification(status: String, progress: Int) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildNotification(status, progress))
    }
}
