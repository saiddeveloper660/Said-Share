package com.example.network

import android.content.Context
import android.util.Log
import com.example.model.FileItem
import com.example.model.IncomingRequest
import com.example.model.TransferProgress
import com.example.storage.FileManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class SaidHttpServer(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private var serverSocket: ServerSocket? = null
    private var acceptJob: Job? = null
    val isRunning = AtomicBoolean(false)

    var deviceName: String = "Said Phone"
    var pin: String = NetworkUtils.generatePin()
    var sessionToken: String = NetworkUtils.generateToken()
    var autoAccept: Boolean = false

    // Files hosted by phone for PC or other phones to download
    val hostedFiles = ConcurrentHashMap<String, FileItem>()

    // Pending incoming transfer requests awaiting user acceptance
    val pendingRequests = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    var onIncomingRequest: ((IncomingRequest) -> Unit)? = null
    var onReceiveProgress: ((TransferProgress) -> Unit)? = null
    var onReceiveCompleted: ((List<File>) -> Unit)? = null

    fun start(port: Int = 8765): Boolean {
        if (isRunning.get()) return true
        return try {
            val server = ServerSocket(port)
            server.reuseAddress = true
            serverSocket = server
            isRunning.set(true)

            acceptJob = scope.launch(Dispatchers.IO) {
                while (isActive && isRunning.get()) {
                    try {
                        val clientSocket = server.accept()
                        launch(Dispatchers.IO) {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (!isRunning.get()) break
                    }
                }
            }
            Log.d("SaidHttpServer", "Server started on port $port")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            isRunning.set(false)
            false
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            // Ignore
        }
        serverSocket = null
        acceptJob?.cancel()
        acceptJob = null
    }

    private suspend fun handleClient(socket: Socket) {
        try {
            socket.use { s ->
                s.soTimeout = 30000
                val inStream = BufferedInputStream(s.getInputStream())
                val outStream = BufferedOutputStream(s.getOutputStream())

                // Parse HTTP Request Line
                val requestLine = readLine(inStream) ?: return
                val tokens = requestLine.split(" ")
                if (tokens.size < 2) return

                val method = tokens[0].uppercase()
                val fullUri = tokens[1]
                val path = fullUri.substringBefore("?")
                val queryString = if (fullUri.contains("?")) fullUri.substringAfter("?") else ""

                // Parse Headers
                val headers = mutableMapOf<String, String>()
                while (true) {
                    val headerLine = readLine(inStream) ?: break
                    if (headerLine.isEmpty()) break
                    val colonIdx = headerLine.indexOf(':')
                    if (colonIdx > 0) {
                        val key = headerLine.substring(0, colonIdx).trim().lowercase()
                        val value = headerLine.substring(colonIdx + 1).trim()
                        headers[key] = value
                    }
                }

                when {
                    method == "GET" && (path == "/" || path == "/index.html") -> {
                        serveWebUi(outStream)
                    }
                    method == "GET" && path == "/api/info" -> {
                        serveApiInfo(outStream)
                    }
                    method == "POST" && path == "/api/transfer/request" -> {
                        handleTransferRequest(inStream, outStream, headers)
                    }
                    method == "POST" && (path == "/api/transfer/upload" || path == "/upload") -> {
                        handleUpload(inStream, outStream, headers, queryString)
                    }
                    method == "GET" && (path == "/api/transfer/download" || path == "/download") -> {
                        handleDownload(outStream, queryString)
                    }
                    method == "OPTIONS" -> {
                        sendResponse(outStream, 204, "No Content", "text/plain", ByteArray(0))
                    }
                    else -> {
                        sendResponse(outStream, 404, "Not Found", "text/plain", "Not Found".toByteArray())
                    }
                }
            }
        } catch (e: Exception) {
            // Client closed connection or error
        }
    }

    private fun serveWebUi(outStream: OutputStream) {
        val files = hostedFiles.values.map { it.name to it.size }
        val html = SaidWebUi.getHtml(deviceName, pin, files)
        val bytes = html.toByteArray(Charsets.UTF_8)
        sendResponse(outStream, 200, "OK", "text/html; charset=utf-8", bytes)
    }

    private fun serveApiInfo(outStream: OutputStream) {
        val json = JSONObject().apply {
            put("app", "SaidShare")
            put("name", deviceName)
            put("type", "phone")
            put("pin", pin)
            put("token", sessionToken)
            put("version", "1.0")
            put("active", true)
        }
        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        sendResponse(outStream, 200, "OK", "application/json", bytes)
    }

    private suspend fun handleTransferRequest(
        inStream: InputStream,
        outStream: OutputStream,
        headers: Map<String, String>
    ) {
        val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
        val bodyBytes = ByteArray(contentLength)
        var readTotal = 0
        while (readTotal < contentLength) {
            val count = inStream.read(bodyBytes, readTotal, contentLength - readTotal)
            if (count < 0) break
            readTotal += count
        }
        val bodyStr = String(bodyBytes, Charsets.UTF_8)
        val json = JSONObject(bodyStr)

        val senderName = json.optString("senderName", "Remote Device")
        val senderIp = json.optString("senderIp", "")
        val token = json.optString("token", "")
        val filesArray = json.optJSONArray("files") ?: JSONArray()
        val fileNames = mutableListOf<String>()
        var totalSize = 0L

        for (i in 0 until filesArray.length()) {
            val item = filesArray.getJSONObject(i)
            fileNames.add(item.optString("name", "file_$i"))
            totalSize += item.optLong("size", 0L)
        }

        val requestId = java.util.UUID.randomUUID().toString()

        val accepted = if (autoAccept) {
            true
        } else {
            val deferred = CompletableDeferred<Boolean>()
            pendingRequests[requestId] = deferred
            val req = IncomingRequest(
                requestId = requestId,
                senderName = senderName,
                senderIp = senderIp,
                fileCount = fileNames.size,
                totalSize = totalSize,
                fileNames = fileNames,
                token = token
            )
            withContext(Dispatchers.Main) {
                onIncomingRequest?.invoke(req)
            }
            try {
                deferred.await()
            } finally {
                pendingRequests.remove(requestId)
            }
        }

        val responseJson = JSONObject().apply {
            put("status", if (accepted) "accepted" else "rejected")
            put("requestId", requestId)
            put("token", sessionToken)
        }
        sendResponse(outStream, 200, "OK", "application/json", responseJson.toString().toByteArray())
    }

    fun respondToRequest(requestId: String, accept: Boolean) {
        pendingRequests[requestId]?.complete(accept)
    }

    private suspend fun handleUpload(
        inStream: InputStream,
        outStream: OutputStream,
        headers: Map<String, String>,
        queryString: String
    ) {
        val contentType = headers["content-type"] ?: ""
        val contentLength = headers["content-length"]?.toLongOrNull() ?: -1L
        val downloadDir = FileManager.getDownloadDir(context)
        val savedFiles = mutableListOf<File>()

        var totalBytesRead = 0L
        val startTime = System.currentTimeMillis()
        var lastProgressTime = 0L

        if (contentType.contains("multipart/form-data")) {
            val boundary = "--" + contentType.substringAfter("boundary=").trim()
            val boundaryBytes = boundary.toByteArray(Charsets.US_ASCII)

            var currentFile: File? = null
            var fileOut: FileOutputStream? = null

            // Stream multipart chunk by chunk
            val buffer = ByteArray(64 * 1024)
            var currentFileName = "incoming_file"
            var currentFileBytes = 0L

            try {
                // Parse multipart stream
                var line = readLine(inStream)
                while (line != null) {
                    if (line.startsWith(boundary)) {
                        fileOut?.flush()
                        fileOut?.close()
                        fileOut = null
                        if (currentFile != null) {
                            savedFiles.add(currentFile)
                            currentFile = null
                        }

                        if (line.endsWith("--")) break // End of multipart

                        // Read Part Headers
                        var partHeader = readLine(inStream)
                        var partFileName: String? = null
                        while (partHeader != null && partHeader.isNotEmpty()) {
                            if (partHeader.contains("filename=")) {
                                partFileName = partHeader.substringAfter("filename=")
                                    .trim('"', ' ', '\r', '\n')
                            }
                            partHeader = readLine(inStream)
                        }

                        if (partFileName != null && partFileName.isNotEmpty()) {
                            currentFileName = partFileName
                            currentFile = FileManager.createUniqueFile(downloadDir, currentFileName)
                            fileOut = FileOutputStream(currentFile)
                            currentFileBytes = 0L
                        }
                    } else if (fileOut != null) {
                        val lineBytes = (line + "\r\n").toByteArray(Charsets.ISO_8859_1)
                        fileOut.write(lineBytes)
                        totalBytesRead += lineBytes.size
                        currentFileBytes += lineBytes.size

                        val now = System.currentTimeMillis()
                        if (now - lastProgressTime > 150) {
                            lastProgressTime = now
                            val elapsedSec = (now - startTime) / 1000.0
                            val speed = if (elapsedSec > 0.1) totalBytesRead / elapsedSec else 0.0

                            val progress = TransferProgress(
                                totalFiles = 1.coerceAtLeast(savedFiles.size + 1),
                                completedFiles = savedFiles.size,
                                currentFileName = currentFileName,
                                currentFileBytes = currentFileBytes,
                                currentFileTotalBytes = contentLength.coerceAtLeast(currentFileBytes),
                                overallBytes = totalBytesRead,
                                overallTotalBytes = contentLength.coerceAtLeast(totalBytesRead),
                                speedBytesPerSec = speed,
                                direction = "RECEIVE",
                                remoteDeviceName = "Sender"
                            )
                            withContext(Dispatchers.Main) {
                                onReceiveProgress?.invoke(progress)
                            }
                        }
                    }
                    line = readLine(inStream)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                fileOut?.flush()
                fileOut?.close()
                if (currentFile != null && currentFile.length() > 0) {
                    savedFiles.add(currentFile)
                }
            }
        } else {
            // Direct binary octet-stream upload
            val fileNameHeader = headers["x-filename"]?.let { URLDecoder.decode(it, "UTF-8") } 
                ?: "received_${System.currentTimeMillis()}"
            val targetFile = FileManager.createUniqueFile(downloadDir, fileNameHeader)
            FileOutputStream(targetFile).use { fos ->
                val buffer = ByteArray(64 * 1024)
                var bytesRead: Int
                while (inStream.read(buffer).also { bytesRead = it } != -1) {
                    fos.write(buffer, 0, bytesRead)
                    totalBytesRead += bytesRead
                    val now = System.currentTimeMillis()
                    if (now - lastProgressTime > 150) {
                        lastProgressTime = now
                        val elapsedSec = (now - startTime) / 1000.0
                        val speed = if (elapsedSec > 0.1) totalBytesRead / elapsedSec else 0.0

                        val progress = TransferProgress(
                            totalFiles = 1,
                            completedFiles = 0,
                            currentFileName = fileNameHeader,
                            currentFileBytes = totalBytesRead,
                            currentFileTotalBytes = contentLength,
                            overallBytes = totalBytesRead,
                            overallTotalBytes = contentLength,
                            speedBytesPerSec = speed,
                            direction = "RECEIVE",
                            remoteDeviceName = "Sender"
                        )
                        withContext(Dispatchers.Main) {
                            onReceiveProgress?.invoke(progress)
                        }
                    }
                    if (contentLength > 0 && totalBytesRead >= contentLength) break
                }
            }
            if (targetFile.length() > 0) {
                savedFiles.add(targetFile)
            }
        }

        withContext(Dispatchers.Main) {
            onReceiveCompleted?.invoke(savedFiles)
        }

        val resJson = JSONObject().apply {
            put("status", "success")
            put("receivedFiles", savedFiles.size)
        }
        sendResponse(outStream, 200, "OK", "application/json", resJson.toString().toByteArray())
    }

    private fun handleDownload(outStream: OutputStream, queryString: String) {
        val fileName = queryString.substringAfter("name=").substringBefore("&")
            .let { URLDecoder.decode(it, "UTF-8") }
        val item = hostedFiles.values.find { it.name == fileName }

        if (item == null) {
            sendResponse(outStream, 404, "Not Found", "text/plain", "File not available".toByteArray())
            return
        }

        try {
            val inStream = if (item.localPath != null) {
                FileInputStream(File(item.localPath))
            } else if (item.uri != null) {
                context.contentResolver.openInputStream(item.uri)
            } else null

            if (inStream == null) {
                sendResponse(outStream, 404, "Not Found", "text/plain", "File could not be read".toByteArray())
                return
            }

            inStream.use { input ->
                val header = buildString {
                    append("HTTP/1.1 200 OK\r\n")
                    append("Content-Type: application/octet-stream\r\n")
                    append("Content-Length: ${item.size}\r\n")
                    append("Content-Disposition: attachment; filename=\"${item.name}\"\r\n")
                    append("Access-Control-Allow-Origin: *\r\n")
                    append("Connection: close\r\n\r\n")
                }
                outStream.write(header.toByteArray(Charsets.US_ASCII))

                val buffer = ByteArray(64 * 1024)
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    outStream.write(buffer, 0, bytesRead)
                }
                outStream.flush()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun readLine(inStream: InputStream): String? {
        val out = ByteArrayOutputStream()
        var b = inStream.read()
        if (b == -1) return null
        while (b != -1 && b != '\n'.code) {
            if (b != '\r'.code) {
                out.write(b)
            }
            b = inStream.read()
        }
        return out.toString("UTF-8")
    }

    private fun sendResponse(
        outStream: OutputStream,
        statusCode: Int,
        statusText: String,
        contentType: String,
        body: ByteArray
    ) {
        val headers = "HTTP/1.1 $statusCode $statusText\r\n" +
                "Content-Type: $contentType\r\n" +
                "Content-Length: ${body.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: *\r\n" +
                "Connection: close\r\n\r\n"
        outStream.write(headers.toByteArray(Charsets.US_ASCII))
        if (body.isNotEmpty()) {
            outStream.write(body)
        }
        outStream.flush()
    }
}
