package com.example.network

import android.util.Log
import com.example.model.DeviceItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SubnetScanner {

    private val client = OkHttpClient.Builder()
        .connectTimeout(400, TimeUnit.MILLISECONDS)
        .readTimeout(600, TimeUnit.MILLISECONDS)
        .build()

    private var scanJob: Job? = null

    fun startScan(
        scope: CoroutineScope,
        localIp: String,
        port: Int = 8765,
        onDeviceFound: (DeviceItem) -> Unit
    ) {
        val subnet = NetworkUtils.getSubnetPrefix(localIp) ?: return
        scanJob?.cancel()

        scanJob = scope.launch(Dispatchers.IO) {
            val semaphore = Semaphore(25) // Scan up to 25 IPs concurrently for fast results (~2-3 seconds total)
            val jobs = (1..254).map { hostId ->
                val targetIp = "$subnet.$hostId"
                if (targetIp == localIp) return@map null

                launch {
                    if (!isActive) return@launch
                    semaphore.withPermit {
                        probeIp(targetIp, port, onDeviceFound)
                    }
                }
            }
            jobs.filterNotNull().forEach { it.join() }
        }
    }

    private fun probeIp(ip: String, port: Int, onDeviceFound: (DeviceItem) -> Unit) {
        try {
            val request = Request.Builder()
                .url("http://$ip:$port/api/info")
                .header("User-Agent", "SaidShare-Android/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string() ?: return
                    val json = JSONObject(bodyStr)
                    val app = json.optString("app", "")
                    if (app == "SaidShare") {
                        val name = json.optString("name", "Unknown Device")
                        val type = json.optString("type", "phone")
                        val token = json.optString("token", null)

                        val device = DeviceItem(
                            id = "$ip:$port",
                            name = name,
                            ip = ip,
                            port = port,
                            deviceType = type,
                            token = token
                        )
                        onDeviceFound(device)
                    }
                }
            }
        } catch (e: Exception) {
            // Not a Said Share peer or unreachable
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        scanJob = null
    }
}
