package com.example.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import com.example.model.DeviceItem

class SaidNsdHelper(private val context: Context) {

    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private val SERVICE_TYPE = "_saidshare._tcp."
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var isRegistered = false
    private var isDiscovering = false

    var onDeviceFound: ((DeviceItem) -> Unit)? = null
    var onDeviceLost: ((String) -> Unit)? = null

    fun registerService(deviceName: String, port: Int, token: String) {
        if (nsdManager == null || isRegistered) return
        NetworkUtils.acquireMulticastLock(context)

        val serviceInfo = NsdServiceInfo().apply {
            serviceName = "SaidShare-$deviceName"
            serviceType = SERVICE_TYPE
            setPort(port)
            setAttribute("token", token)
            setAttribute("name", deviceName)
            setAttribute("type", "phone")
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(NsdServiceInfo: NsdServiceInfo) {
                isRegistered = true
                Log.d("SaidNsdHelper", "Service registered: ${NsdServiceInfo.serviceName}")
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                isRegistered = false
                Log.e("SaidNsdHelper", "Registration failed: $errorCode")
            }

            override fun onServiceUnregistered(arg0: NsdServiceInfo) {
                isRegistered = false
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                isRegistered = false
            }
        }

        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun unregisterService() {
        if (nsdManager != null && isRegistered && registrationListener != null) {
            try {
                nsdManager.unregisterService(registrationListener)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        isRegistered = false
        registrationListener = null
    }

    fun startDiscovery() {
        if (nsdManager == null || isDiscovering) return
        NetworkUtils.acquireMulticastLock(context)

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                isDiscovering = true
                Log.d("SaidNsdHelper", "NSD discovery started: $regType")
            }

            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType.contains("_saidshare._tcp")) {
                    resolveService(service)
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                Log.d("SaidNsdHelper", "Service lost: ${service.serviceName}")
                onDeviceLost?.invoke(service.serviceName)
            }

            override fun onDiscoveryStopped(serviceType: String) {
                isDiscovering = false
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                isDiscovering = false
                try {
                    nsdManager.stopServiceDiscovery(this)
                } catch (e: Exception) {
                    // Ignore
                }
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                isDiscovering = false
            }
        }

        try {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun resolveService(serviceInfo: NsdServiceInfo) {
        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.w("SaidNsdHelper", "Resolve failed: $errorCode")
            }

            override fun onServiceResolved(resolved: NsdServiceInfo) {
                val host = resolved.host?.hostAddress ?: return
                val port = resolved.port
                val attributes = resolved.attributes
                val name = attributes["name"]?.let { String(it) } 
                    ?: resolved.serviceName.removePrefix("SaidShare-")
                val token = attributes["token"]?.let { String(it) }
                val type = attributes["type"]?.let { String(it) } ?: "phone"

                val device = DeviceItem(
                    id = "$host:$port",
                    name = name,
                    ip = host,
                    port = port,
                    deviceType = type,
                    token = token
                )
                onDeviceFound?.invoke(device)
            }
        }

        try {
            nsdManager?.resolveService(serviceInfo, resolveListener)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopDiscovery() {
        if (nsdManager != null && isDiscovering && discoveryListener != null) {
            try {
                nsdManager.stopServiceDiscovery(discoveryListener)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        isDiscovering = false
        discoveryListener = null
    }

    fun destroy() {
        unregisterService()
        stopDiscovery()
        NetworkUtils.releaseMulticastLock()
    }
}
