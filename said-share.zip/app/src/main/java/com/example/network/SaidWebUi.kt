package com.example.network

object SaidWebUi {

    fun getHtml(
        deviceName: String,
        pin: String,
        availableFiles: List<Pair<String, Long>> = emptyList()
    ): String {
        val filesJsonArray = availableFiles.joinToString(",") { 
            "{\"name\": \"${escapeJson(it.first)}\", \"size\": ${it.second}}" 
        }

        return """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Said Share - Fast Local File Transfer</title>
  <style>
    :root {
      --bg: #0b1120;
      --surface: #151e32;
      --card: #1e293b;
      --card-border: #334155;
      --primary: #06b6d4;
      --primary-hover: #0891b2;
      --accent: #10b981;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --error: #f43f5e;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    body { background-color: var(--bg); color: var(--text-main); min-height: 100vh; display: flex; flex-direction: column; align-items: center; padding: 24px 16px; }
    .container { width: 100%; max-width: 760px; }
    
    /* Header */
    header { text-align: center; margin-bottom: 28px; }
    .logo-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(6, 182, 212, 0.15); border: 1px solid var(--primary); padding: 6px 14px; border-radius: 9999px; font-size: 13px; font-weight: 600; color: var(--primary); margin-bottom: 12px; }
    h1 { font-size: 32px; font-weight: 800; letter-spacing: -0.5px; background: linear-gradient(135deg, #38bdf8, #06b6d4, #10b981); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .subtitle { color: var(--text-muted); font-size: 15px; margin-top: 4px; }
    
    /* Device Info Bar */
    .device-bar { background: var(--surface); border: 1px solid var(--card-border); border-radius: 14px; padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .device-info { display: flex; align-items: center; gap: 12px; }
    .device-icon { width: 40px; height: 40px; background: var(--card); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 20px; }
    .device-name { font-weight: 700; font-size: 16px; }
    .device-status { font-size: 12px; color: var(--accent); display: flex; align-items: center; gap: 6px; }
    .status-dot { width: 8px; height: 8px; background: var(--accent); border-radius: 50%; display: inline-block; box-shadow: 0 0 8px var(--accent); }
    .pin-badge { background: var(--card); border: 1px solid var(--card-border); padding: 6px 12px; border-radius: 8px; font-size: 13px; font-weight: 700; letter-spacing: 1px; color: var(--text-main); }
    
    /* Tabs */
    .tabs { display: flex; gap: 10px; margin-bottom: 20px; }
    .tab-btn { flex: 1; padding: 12px; border-radius: 10px; border: 1px solid var(--card-border); background: var(--surface); color: var(--text-muted); font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
    .tab-btn.active { background: var(--primary); color: #042f2e; border-color: var(--primary); font-weight: 700; }
    
    /* Upload Card */
    .card { background: var(--surface); border: 1px solid var(--card-border); border-radius: 18px; padding: 24px; margin-bottom: 24px; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3); }
    
    .dropzone { border: 2px dashed var(--card-border); border-radius: 14px; padding: 40px 20px; text-align: center; cursor: pointer; transition: all 0.2s; background: rgba(30, 41, 59, 0.4); }
    .dropzone:hover, .dropzone.dragover { border-color: var(--primary); background: rgba(6, 182, 212, 0.08); }
    .drop-icon { font-size: 48px; margin-bottom: 12px; }
    .drop-title { font-size: 18px; font-weight: 700; margin-bottom: 6px; }
    .drop-sub { font-size: 13px; color: var(--text-muted); }
    
    /* File List */
    .file-list { margin-top: 20px; display: flex; flex-direction: column; gap: 10px; }
    .file-item { display: flex; align-items: center; justify-content: space-between; background: var(--card); border: 1px solid var(--card-border); padding: 10px 14px; border-radius: 10px; font-size: 14px; }
    .file-info { display: flex; align-items: center; gap: 10px; overflow: hidden; }
    .file-name { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 320px; }
    .file-size { color: var(--text-muted); font-size: 12px; }
    .remove-btn { background: none; border: none; color: var(--error); cursor: pointer; font-size: 16px; padding: 4px; }
    
    /* Progress */
    .progress-container { margin-top: 20px; display: none; }
    .progress-labels { display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 8px; }
    .progress-bar-bg { width: 100%; height: 10px; background: var(--card); border-radius: 5px; overflow: hidden; }
    .progress-bar-fill { width: 0%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent)); transition: width 0.1s linear; }
    .progress-meta { display: flex; justify-content: space-between; font-size: 12px; color: var(--text-muted); margin-top: 6px; }
    
    /* Action Buttons */
    .btn { width: 100%; padding: 14px; border-radius: 12px; border: none; font-size: 15px; font-weight: 700; cursor: pointer; transition: all 0.2s; margin-top: 18px; }
    .btn-primary { background: linear-gradient(135deg, var(--primary), #0284c7); color: #ffffff; }
    .btn-primary:hover { filter: brightness(1.1); }
    .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
    
    /* Download Table */
    .download-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: var(--card); border: 1px solid var(--card-border); border-radius: 12px; margin-bottom: 10px; }
    .dl-btn { background: var(--primary); color: #042f2e; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 700; font-size: 13px; text-decoration: none; cursor: pointer; }
    
    /* Footer */
    footer { text-align: center; color: var(--text-muted); font-size: 12px; margin-top: 40px; }
    footer a { color: var(--primary); text-decoration: none; }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="logo-badge">⚡ Said Share Local Transfer</div>
      <h1>SAID SHARE</h1>
      <p class="subtitle">Fast, Private & Direct Local Wi-Fi Sharing</p>
    </header>

    <div class="device-bar">
      <div class="device-info">
        <div class="device-icon">📱</div>
        <div>
          <div class="device-name">$deviceName</div>
          <div class="device-status"><span class="status-dot"></span> Ready on Local Wi-Fi</div>
        </div>
      </div>
      <div class="pin-badge">PIN: $pin</div>
    </div>

    <div class="tabs">
      <button class="tab-btn active" id="tabUploadBtn" onclick="switchTab('upload')">📤 Send Files to Phone</button>
      <button class="tab-btn" id="tabDownloadBtn" onclick="switchTab('download')">📥 Download from Phone</button>
    </div>

    <!-- Upload Tab -->
    <div id="uploadTab" class="card">
      <div class="dropzone" id="dropzone" onclick="document.getElementById('fileInput').click()">
        <div class="drop-icon">📁</div>
        <div class="drop-title">Drop files here or click to browse</div>
        <div class="drop-sub">Transfer photos, videos, documents, or any file up to 5 GB+</div>
        <input type="file" id="fileInput" multiple style="display: none;" onchange="handleFileSelect(this.files)">
      </div>

      <div class="file-list" id="selectedFilesList"></div>

      <div class="progress-container" id="progressSection">
        <div class="progress-labels">
          <span id="progressFileText">Uploading files...</span>
          <span id="progressPercent">0%</span>
        </div>
        <div class="progress-bar-bg">
          <div class="progress-bar-fill" id="progressBar"></div>
        </div>
        <div class="progress-meta">
          <span id="progressSpeed">0 MB/s</span>
          <span id="progressEta">Calculating...</span>
        </div>
      </div>

      <button class="btn btn-primary" id="uploadBtn" onclick="startUpload()" disabled>Send to Phone</button>
    </div>

    <!-- Download Tab -->
    <div id="downloadTab" class="card" style="display: none;">
      <h3 style="font-size: 16px; margin-bottom: 14px;">Available Files on Phone</h3>
      <div id="downloadListContainer">
        <!-- Rendered by JS -->
      </div>
    </div>

    <footer>
      Said Share &bull; Developed by <strong>Said Developer</strong> &bull; Direct Local Network Transfer
    </footer>
  </div>

  <script>
    let selectedFiles = [];
    const serverFiles = $filesJsonArray;

    function formatBytes(bytes) {
      if (bytes === 0) return '0 B';
      const k = 1024;
      const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function switchTab(tab) {
      document.getElementById('tabUploadBtn').classList.toggle('active', tab === 'upload');
      document.getElementById('tabDownloadBtn').classList.toggle('active', tab === 'download');
      document.getElementById('uploadTab').style.display = tab === 'upload' ? 'block' : 'none';
      document.getElementById('downloadTab').style.display = tab === 'download' ? 'block' : 'none';
      if (tab === 'download') renderDownloadList();
    }

    const dropzone = document.getElementById('dropzone');
    ['dragenter', 'dragover'].forEach(name => {
      dropzone.addEventListener(name, (e) => { e.preventDefault(); dropzone.classList.add('dragover'); }, false);
    });
    ['dragleave', 'drop'].forEach(name => {
      dropzone.addEventListener(name, (e) => { e.preventDefault(); dropzone.classList.remove('dragover'); }, false);
    });
    dropzone.addEventListener('drop', (e) => {
      handleFileSelect(e.dataTransfer.files);
    });

    function handleFileSelect(files) {
      for (let i = 0; i < files.length; i++) {
        selectedFiles.push(files[i]);
      }
      renderFileList();
    }

    function removeFile(index) {
      selectedFiles.splice(index, 1);
      renderFileList();
    }

    function renderFileList() {
      const list = document.getElementById('selectedFilesList');
      list.innerHTML = '';
      if (selectedFiles.length === 0) {
        document.getElementById('uploadBtn').disabled = true;
        document.getElementById('uploadBtn').innerText = 'Send to Phone';
        return;
      }

      let totalSize = 0;
      selectedFiles.forEach((file, idx) => {
        totalSize += file.size;
        const item = document.createElement('div');
        item.className = 'file-item';
        item.innerHTML = 
          '<div class="file-info">' +
            '<span>📄</span>' +
            '<div>' +
              '<div class="file-name">' + file.name + '</div>' +
              '<div class="file-size">' + formatBytes(file.size) + '</div>' +
            '</div>' +
          '</div>' +
          '<button class="remove-btn" onclick="removeFile(' + idx + ')">&times;</button>';
        list.appendChild(item);
      });

      document.getElementById('uploadBtn').disabled = false;
      const sSuffix = selectedFiles.length > 1 ? 's' : '';
      document.getElementById('uploadBtn').innerText = 'Send ' + selectedFiles.length + ' file' + sSuffix + ' (' + formatBytes(totalSize) + ')';
    }

    function startUpload() {
      if (selectedFiles.length === 0) return;

      const progressSection = document.getElementById('progressSection');
      const progressBar = document.getElementById('progressBar');
      const progressPercent = document.getElementById('progressPercent');
      const progressFileText = document.getElementById('progressFileText');
      const progressSpeed = document.getElementById('progressSpeed');
      const uploadBtn = document.getElementById('uploadBtn');

      progressSection.style.display = 'block';
      uploadBtn.disabled = true;

      const formData = new FormData();
      selectedFiles.forEach(file => {
        formData.append('files', file, file.name);
      });

      const xhr = new XMLHttpRequest();
      let startTime = Date.now();

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 100);
          progressBar.style.width = percent + '%';
          progressPercent.innerText = percent + '%';
          progressFileText.innerText = 'Uploading ' + formatBytes(event.loaded) + ' of ' + formatBytes(event.total);

          const elapsedSec = (Date.now() - startTime) / 1000;
          if (elapsedSec > 0.5) {
            const speed = event.loaded / elapsedSec;
            progressSpeed.innerText = formatBytes(speed) + '/s';
            const remainingBytes = event.total - event.loaded;
            const eta = Math.round(remainingBytes / speed);
            document.getElementById('progressEta').innerText = eta > 0 ? eta + 's remaining' : 'Finishing...';
          }
        }
      };

      xhr.onload = () => {
        if (xhr.status === 200) {
          progressFileText.innerText = '✅ Transfer Complete!';
          progressBar.style.width = '100%';
          progressPercent.innerText = '100%';
          uploadBtn.innerText = 'Sent Successfully!';
          uploadBtn.style.background = '#10b981';
          selectedFiles = [];
          setTimeout(() => {
            renderFileList();
            progressSection.style.display = 'none';
            uploadBtn.style.background = '';
          }, 3000);
        } else {
          progressFileText.innerText = '❌ Transfer Failed: ' + (xhr.responseText || 'Error');
          uploadBtn.disabled = false;
        }
      };

      xhr.onerror = () => {
        progressFileText.innerText = '❌ Network Error. Check connection.';
        uploadBtn.disabled = false;
      };

      xhr.open('POST', '/api/transfer/upload?pin=' + encodeURIComponent('$pin'), true);
      xhr.send(formData);
    }

    function renderDownloadList() {
      const container = document.getElementById('downloadListContainer');
      container.innerHTML = '';
      if (!serverFiles || serverFiles.length === 0) {
        container.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 24px;">No files currently shared for download by the phone.</p>';
        return;
      }

      serverFiles.forEach(f => {
        const row = document.createElement('div');
        row.className = 'download-item';
        row.innerHTML = 
          '<div>' +
            '<div style="font-weight: 600;">' + f.name + '</div>' +
            '<div style="font-size: 12px; color: var(--text-muted);">' + formatBytes(f.size) + '</div>' +
          '</div>' +
          '<a class="dl-btn" href="/api/transfer/download?name=' + encodeURIComponent(f.name) + '" download>Download</a>';
        container.appendChild(row);
      });
    }
  </script>
</body>
</html>
        """.trimIndent()
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")
    }
}
