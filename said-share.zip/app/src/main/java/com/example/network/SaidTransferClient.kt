package com.example.network

import android.content.Context
import com.example.model.DeviceItem
import com.example.model.FileItem
import com.example.model.TransferProgress
import com.example.model.TransferSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class SaidTransferClient(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.MINUTES) // Allow large file streaming
        .readTimeout(60, TimeUnit.MINUTES)
        .build()

    val isPaused = AtomicBoolean(false)
    val isCancelled = AtomicBoolean(false)

    suspend fun sendHandshake(
        device: DeviceItem,
        senderDeviceName: String,
        files: List<FileItem>
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject().apply {
                put("senderName", senderDeviceName)
                put("token", device.token ?: "")
                val array = JSONArray()
                files.forEach {
                    array.put(JSONObject().apply {
                        put("name", it.name)
                        put("size", it.size)
                    })
                }
                put("files", array)
            }

            val body = RequestBody.create(
                "application/json".toMediaTypeOrNull(),
                json.toString()
            )

            val request = Request.Builder()
                .url("${device.address}/api/transfer/request")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Receiver replied with HTTP ${response.code}"))
                }
                val resStr = response.body?.string() ?: ""
                val resJson = JSONObject(resStr)
                val status = resJson.optString("status")
                if (status == "accepted") {
                    Result.success(true)
                } else {
                    Result.failure(Exception("Transfer request was declined by the receiver."))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun transferFiles(
        device: DeviceItem,
        files: List<FileItem>,
        onProgress: (TransferProgress) -> Unit
    ): Result<TransferSummary> = withContext(Dispatchers.IO) {
        isPaused.set(false)
        isCancelled.set(false)

        val totalBytes = files.sumOf { it.size }
        var overallBytesTransferred = 0L
        val startTime = System.currentTimeMillis()
        var completedFiles = 0

        try {
            for (file in files) {
                if (isCancelled.get()) {
                    return@withContext Result.failure(Exception("Transfer cancelled by user"))
                }

                while (isPaused.get()) {
                    delay(200)
                    if (isCancelled.get()) {
                        return@withContext Result.failure(Exception("Transfer cancelled by user"))
                    }
                }

                val result = sendSingleFile(
                    device = device,
                    file = file,
                    totalFiles = files.size,
                    completedFiles = completedFiles,
                    overallBytesSoFar = overallBytesTransferred,
                    totalOverallBytes = totalBytes,
                    startTime = startTime,
                    onProgress = onProgress
                )

                if (result.isFailure) {
                    return@withContext Result.failure(result.exceptionOrNull() ?: Exception("Failed sending ${file.name}"))
                }

                overallBytesTransferred += file.size
                completedFiles++
            }

            val totalDuration = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            val avgSpeed = if (totalDuration > 0) (totalBytes * 1000.0) / totalDuration else 0.0

            Result.success(
                TransferSummary(
                    totalFiles = files.size,
                    totalBytes = totalBytes,
                    avgSpeedBytesPerSec = avgSpeed,
                    durationMillis = totalDuration,
                    direction = "SEND",
                    remoteDeviceName = device.name
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun sendSingleFile(
        device: DeviceItem,
        file: FileItem,
        totalFiles: Int,
        completedFiles: Int,
        overallBytesSoFar: Long,
        totalOverallBytes: Long,
        startTime: Long,
        onProgress: (TransferProgress) -> Unit
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val uri = file.uri ?: return@withContext Result.failure(Exception("Missing file URI"))

            var lastReportTime = 0L
            var fileBytesSent = 0L

            val countingBody = object : RequestBody() {
                override fun contentType() = (file.mimeType).toMediaTypeOrNull()

                override fun contentLength() = file.size

                override fun writeTo(sink: BufferedSink) {
                    val inStream: InputStream = contentResolver.openInputStream(uri)
                        ?: throw Exception("Cannot open file stream")

                    inStream.use { input ->
                        val buffer = ByteArray(64 * 1024)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            if (isCancelled.get()) {
                                throw Exception("Transfer cancelled")
                            }
                            while (isPaused.get()) {
                                Thread.sleep(200)
                                if (isCancelled.get()) throw Exception("Transfer cancelled")
                            }

                            sink.write(buffer, 0, read)
                            fileBytesSent += read

                            val now = System.currentTimeMillis()
                            if (now - lastReportTime > 150) {
                                lastReportTime = now
                                val elapsedSec = (now - startTime) / 1000.0
                                val currentOverall = overallBytesSoFar + fileBytesSent
                                val speed = if (elapsedSec > 0.1) currentOverall / elapsedSec else 0.0

                                val progress = TransferProgress(
                                    totalFiles = totalFiles,
                                    completedFiles = completedFiles,
                                    currentFileName = file.name,
                                    currentFileBytes = fileBytesSent,
                                    currentFileTotalBytes = file.size,
                                    overallBytes = currentOverall,
                                    overallTotalBytes = totalOverallBytes,
                                    speedBytesPerSec = speed,
                                    isPaused = isPaused.get(),
                                    isCancelled = isCancelled.get(),
                                    direction = "SEND",
                                    remoteDeviceName = device.name
                                )
                                onProgress(progress)
                            }
                        }
                    }
                }
            }

            val encodedName = URLEncoder.encode(file.name, "UTF-8")
            val request = Request.Builder()
                .url("${device.address}/api/transfer/upload")
                .header("x-filename", encodedName)
                .header("Content-Type", file.mimeType)
                .post(countingBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Upload failed: HTTP ${response.code}"))
                }
            }

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun pause() {
        isPaused.set(true)
    }

    fun resume() {
        isPaused.set(false)
    }

    fun cancel() {
        isCancelled.set(true)
    }
}
