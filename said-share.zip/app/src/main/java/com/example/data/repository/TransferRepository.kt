package com.example.data.repository

import com.example.data.dao.TransferDao
import com.example.data.model.TransferEntity
import kotlinx.coroutines.flow.Flow

class TransferRepository(private val transferDao: TransferDao) {
    val allTransfers: Flow<List<TransferEntity>> = transferDao.getAllTransfers()
    val recentTransfers: Flow<List<TransferEntity>> = transferDao.getRecentTransfers(5)
    val sentCount: Flow<Int> = transferDao.getSentCount()
    val receivedCount: Flow<Int> = transferDao.getReceivedCount()

    suspend fun recordTransfer(transfer: TransferEntity): Long {
        return transferDao.insert(transfer)
    }

    suspend fun updateTransfer(transfer: TransferEntity) {
        transferDao.update(transfer)
    }

    suspend fun deleteTransfer(id: Long) {
        transferDao.deleteById(id)
    }

    suspend fun clearHistory() {
        transferDao.clearAll()
    }
}
