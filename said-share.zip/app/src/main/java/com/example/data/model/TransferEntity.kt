package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transfers")
data class TransferEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fileName: String,
    val fileSize: Long,
    val fileCount: Int = 1,
    val direction: String, // "SENT" or "RECEIVED"
    val remoteDeviceName: String,
    val status: String, // "COMPLETED", "FAILED", "CANCELLED"
    val localPath: String? = null,
    val mimeType: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
