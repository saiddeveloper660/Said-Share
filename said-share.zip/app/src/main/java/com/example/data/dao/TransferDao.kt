package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TransferEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferDao {
    @Query("SELECT * FROM transfers ORDER BY timestamp DESC")
    fun getAllTransfers(): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfers ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentTransfers(limit: Int = 5): Flow<List<TransferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transfer: TransferEntity): Long

    @Update
    suspend fun update(transfer: TransferEntity)

    @Query("DELETE FROM transfers WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transfers")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM transfers WHERE direction = 'SENT' AND status = 'COMPLETED'")
    fun getSentCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM transfers WHERE direction = 'RECEIVED' AND status = 'COMPLETED'")
    fun getReceivedCount(): Flow<Int>
}
