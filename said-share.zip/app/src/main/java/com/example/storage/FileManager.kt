package com.example.storage

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.example.model.FileItem
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileManager {

    fun getFileItemFromUri(context: Context, uri: Uri): FileItem {
        var name = "unknown_file"
        var size = 0L
        val mimeType = context.contentResolver.getType(uri) ?: "*/*"

        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex) ?: "file_${System.currentTimeMillis()}"
                }
                if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                    size = cursor.getLong(sizeIndex)
                }
            }
        }

        return FileItem(
            uri = uri,
            name = name,
            size = size,
            mimeType = mimeType
        )
    }

    fun getDownloadDir(context: Context): File {
        // App specific external downloads folder ensures full read/write permission without SAF restrictions
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SaidShare")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun createUniqueFile(dir: File, originalName: String): File {
        val safeName = originalName.replace("[\\\\/:*?\"<>|]".toRegex(), "_")
        var file = File(dir, safeName)
        if (!file.exists()) return file

        val dotIndex = safeName.lastIndexOf('.')
        val baseName = if (dotIndex > 0) safeName.substring(0, dotIndex) else safeName
        val extension = if (dotIndex > 0) safeName.substring(dotIndex) else ""

        var counter = 1
        while (file.exists()) {
            file = File(dir, "${baseName}_$counter$extension")
            counter++
        }
        return file
    }

    fun openFile(context: Context, filePath: String): Boolean {
        return try {
            val file = File(filePath)
            if (!file.exists()) return false

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val extension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(file).toString())
            val mimeType = if (extension.isNotEmpty()) {
                MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase(Locale.ROOT)) ?: "*/*"
            } else {
                "*/*"
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val format = DecimalFormat("#,##0.#")
        return "${format.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }

    fun formatSpeed(bytesPerSec: Double): String {
        return "${formatFileSize(bytesPerSec.toLong())}/s"
    }

    fun formatRemainingTime(seconds: Long): String {
        if (seconds <= 0) return "Calculating..."
        if (seconds < 60) return "${seconds}s remaining"
        val mins = seconds / 60
        val remainingSecs = seconds % 60
        return "${mins}m ${remainingSecs}s remaining"
    }

    fun formatTimestamp(timestamp: Long): String {
        val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}
