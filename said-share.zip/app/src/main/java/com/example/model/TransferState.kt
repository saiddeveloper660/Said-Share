package com.example.model

data class TransferProgress(
    val totalFiles: Int = 0,
    val completedFiles: Int = 0,
    val currentFileName: String = "",
    val currentFileBytes: Long = 0L,
    val currentFileTotalBytes: Long = 0L,
    val overallBytes: Long = 0L,
    val overallTotalBytes: Long = 0L,
    val speedBytesPerSec: Double = 0.0,
    val isPaused: Boolean = false,
    val isCancelled: Boolean = false,
    val direction: String = "SEND", // "SEND" or "RECEIVE"
    val remoteDeviceName: String = "",
    val errorMessage: String? = null
) {
    val currentFilePercent: Float
        get() = if (currentFileTotalBytes > 0) {
            (currentFileBytes.toFloat() / currentFileTotalBytes.toFloat()).coerceIn(0f, 1f)
        } else 0f

    val overallPercent: Float
        get() = if (overallTotalBytes > 0) {
            (overallBytes.toFloat() / overallTotalBytes.toFloat()).coerceIn(0f, 1f)
        } else 0f

    val remainingSeconds: Long
        get() = if (speedBytesPerSec > 1024 && overallTotalBytes > overallBytes) {
            val remainingBytes = overallTotalBytes - overallBytes
            (remainingBytes / speedBytesPerSec).toLong().coerceAtLeast(1)
        } else 0L
}

data class IncomingRequest(
    val requestId: String,
    val senderName: String,
    val senderIp: String,
    val fileCount: Int,
    val totalSize: Long,
    val fileNames: List<String>,
    val token: String
)

data class TransferSummary(
    val totalFiles: Int,
    val totalBytes: Long,
    val avgSpeedBytesPerSec: Double,
    val durationMillis: Long,
    val direction: String,
    val remoteDeviceName: String,
    val savedPaths: List<String> = emptyList()
)
