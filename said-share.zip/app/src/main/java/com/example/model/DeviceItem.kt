package com.example.model

data class DeviceItem(
    val id: String,
    val name: String,
    val ip: String,
    val port: Int = 8765,
    val deviceType: String = "phone", // "phone", "pc", "tablet"
    val token: String? = null,
    val lastSeen: Long = System.currentTimeMillis()
) {
    val address: String get() = "http://$ip:$port"
}
