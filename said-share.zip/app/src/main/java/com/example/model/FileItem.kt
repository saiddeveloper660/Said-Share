package com.example.model

import android.net.Uri

data class FileItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val uri: Uri? = null,
    val name: String,
    val size: Long,
    val mimeType: String = "*/*",
    val localPath: String? = null
)
