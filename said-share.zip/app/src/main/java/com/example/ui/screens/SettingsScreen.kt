package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.storage.FileManager
import com.example.ui.components.SaidBottomNavBar
import com.example.ui.components.SaidTopAppBar
import com.example.ui.theme.SaidCyan
import com.example.ui.theme.SaidEmerald
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MainViewModel

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val deviceName by viewModel.deviceName.collectAsState()
    val localIp by viewModel.localIp.collectAsState()
    val isWifiConnected by viewModel.isWifiConnected.collectAsState()
    val isServerRunning by viewModel.isServerRunning.collectAsState()
    val autoAccept by viewModel.autoAccept.collectAsState()
    val keepScreenAwake by viewModel.keepScreenAwake.collectAsState()
    val darkMode by viewModel.darkMode.collectAsState()

    var showEditNameDialog by remember { mutableStateOf(false) }
    var tempDeviceName by remember { mutableStateOf(deviceName) }

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    Scaffold(
        topBar = {
            SaidTopAppBar(
                title = "Settings",
                canNavigateBack = true,
                onNavigateBack = { viewModel.navigateTo(AppScreen.HOME) }
            )
        },
        bottomBar = {
            SaidBottomNavBar(
                currentScreen = AppScreen.SETTINGS,
                onNavigate = { viewModel.navigateTo(it) }
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Spacer(modifier = Modifier.height(6.dp))

            // General Section
            SettingsSectionHeader(title = "General")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    // Device Name Setting
                    SettingsRow(
                        icon = Icons.Default.Devices,
                        title = "Device Name",
                        subtitle = deviceName,
                        onClick = {
                            tempDeviceName = deviceName
                            showEditNameDialog = true
                        },
                        testTag = "setting_device_name"
                    )

                    // Dark Mode Toggle
                    SettingsToggleRow(
                        icon = Icons.Default.DarkMode,
                        title = "Dark Mode",
                        subtitle = when (darkMode) {
                            true -> "Enabled"
                            false -> "Disabled (Light Mode)"
                            null -> "Follow System"
                        },
                        checked = darkMode ?: true,
                        onCheckedChange = { checked ->
                            viewModel.setDarkMode(checked)
                        },
                        testTag = "setting_dark_mode_switch"
                    )
                }
            }

            // Transfer Section
            SettingsSectionHeader(title = "Transfer")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    // Auto Accept Setting (OFF by default)
                    SettingsToggleRow(
                        icon = Icons.Default.Security,
                        title = "Auto-Accept Transfers",
                        subtitle = if (autoAccept) "Transfers start automatically" else "Prompt confirmation first (Recommended)",
                        checked = autoAccept,
                        onCheckedChange = { viewModel.setAutoAccept(it) },
                        testTag = "setting_auto_accept_switch"
                    )

                    // Keep Screen Awake
                    SettingsToggleRow(
                        icon = Icons.Default.Visibility,
                        title = "Keep Screen Awake",
                        subtitle = "Prevents device sleep during transfers",
                        checked = keepScreenAwake,
                        onCheckedChange = { viewModel.setKeepScreenAwake(it) },
                        testTag = "setting_keep_awake_switch"
                    )

                    // Download folder location
                    SettingsRow(
                        icon = Icons.Default.Folder,
                        title = "Save Location",
                        subtitle = "Downloads/SaidShare",
                        onClick = {},
                        testTag = "setting_download_folder"
                    )
                }
            }

            // Connection Section
            SettingsSectionHeader(title = "Connection")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    InfoLine(label = "Local IP Address", value = localIp)
                    InfoLine(label = "Transfer Port", value = "${viewModel.serverPort}")
                    InfoLine(
                        label = "Wi-Fi Status",
                        value = if (isWifiConnected) "Connected" else "Disconnected",
                        valueColor = if (isWifiConnected) SaidEmerald else SaidCyan
                    )
                    InfoLine(
                        label = "Receiver Server",
                        value = if (isServerRunning) "Active (Ready)" else "Standby",
                        valueColor = if (isServerRunning) SaidEmerald else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // About Section
            SettingsSectionHeader(title = "About")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "SAID SHARE",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Fast, Private & Local File Sharing without cloud, account, or internet.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    InfoLine(label = "Version", value = "1.0.0 (Release)")
                    InfoLine(label = "Developer", value = "Said Developer")
                    InfoLine(label = "Architecture", value = "Offline-First Local Network")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Edit Device Name Dialog
    if (showEditNameDialog) {
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            title = { Text("Edit Device Name", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = tempDeviceName,
                    onValueChange = { tempDeviceName = it },
                    label = { Text("Device Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_device_name_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setDeviceName(tempDeviceName)
                        showEditNameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaidCyan),
                    modifier = Modifier.testTag("save_device_name_btn")
                ) {
                    Text("Save", color = Color(0xFF042F2E), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditNameDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = SaidCyan,
        modifier = Modifier.padding(start = 4.dp)
    )
}

@Composable
fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(SaidCyan.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = SaidCyan,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SettingsToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String = ""
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(SaidCyan.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = SaidCyan,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = SaidCyan
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
fun InfoLine(
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = valueColor
        )
    }
}
