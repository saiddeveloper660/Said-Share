package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeviceItem
import com.example.storage.FileManager
import com.example.ui.components.DeviceCard
import com.example.ui.components.FilePreviewCard
import com.example.ui.components.SaidTopAppBar
import com.example.ui.theme.SaidCoral
import com.example.ui.theme.SaidCyan
import com.example.ui.theme.SaidEmerald
import com.example.ui.theme.SaidSky
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MainViewModel

@Composable
fun SendScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val discoveredDevices by viewModel.discoveredDevices.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var showManualIpDialog by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }
    var manualIpText by remember { mutableStateOf("") }
    var manualPortText by remember { mutableStateOf("8765") }
    var qrContentText by remember { mutableStateOf("") }

    // Start discovery when entering send screen
    DisposableEffect(Unit) {
        viewModel.startDiscovery()
        onDispose {
            viewModel.stopDiscovery()
        }
    }

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    // Modern SAF Multi-Document Picker
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.addFiles(uris)
        }
    }

    Scaffold(
        topBar = {
            SaidTopAppBar(
                title = "Send Files",
                canNavigateBack = true,
                onNavigateBack = { viewModel.navigateTo(AppScreen.HOME) },
                actions = {
                    if (selectedFiles.isNotEmpty()) {
                        TextButton(
                            onClick = { viewModel.clearSelectedFiles() },
                            modifier = Modifier.testTag("clear_all_files_btn")
                        ) {
                            Text("Clear", color = SaidCoral, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Error banner if any
            if (errorMessage != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SaidCoral.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = SaidCoral,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { viewModel.clearError() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Dismiss", tint = SaidCoral)
                            }
                        }
                    }
                }
            }

            // Quick Category Selectors
            item {
                Text(
                    text = "Select Files to Send",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CategoryButton(
                        title = "All Files",
                        icon = Icons.Default.Folder,
                        onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.weight(1f),
                        testTag = "picker_all_files"
                    )
                    CategoryButton(
                        title = "Photos",
                        icon = Icons.Default.Image,
                        onClick = { filePickerLauncher.launch(arrayOf("image/*")) },
                        modifier = Modifier.weight(1f),
                        testTag = "picker_photos"
                    )
                    CategoryButton(
                        title = "Videos",
                        icon = Icons.Default.Movie,
                        onClick = { filePickerLauncher.launch(arrayOf("video/*")) },
                        modifier = Modifier.weight(1f),
                        testTag = "picker_videos"
                    )
                    CategoryButton(
                        title = "Docs",
                        icon = Icons.Default.Description,
                        onClick = { filePickerLauncher.launch(arrayOf("application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/*")) },
                        modifier = Modifier.weight(1f),
                        testTag = "picker_docs"
                    )
                }
            }

            // Selected Files List
            if (selectedFiles.isNotEmpty()) {
                item {
                    val totalSize = selectedFiles.sumOf { it.size }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = SaidCyan.copy(alpha = 0.12f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${selectedFiles.size} File${if (selectedFiles.size > 1) "s" else ""} Selected",
                                fontWeight = FontWeight.Bold,
                                color = SaidCyan,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Total ${FileManager.formatFileSize(totalSize)}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                items(selectedFiles) { file ->
                    FilePreviewCard(
                        file = file,
                        onRemove = { viewModel.removeFile(file) }
                    )
                }
            }

            // Step 2: Available Devices Header
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Available Devices",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (isScanning) {
                            Spacer(modifier = Modifier.width(8.dp))
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = SaidCyan
                            )
                        }
                    }
                    IconButton(
                        onClick = { viewModel.startDiscovery() },
                        modifier = Modifier.testTag("rescan_devices_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Rescan",
                            tint = SaidCyan
                        )
                    }
                }
            }

            // Discovered Devices List
            if (discoveredDevices.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Radar,
                                contentDescription = null,
                                tint = SaidCyan,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Searching for nearby devices...",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Make sure the receiver device is in 'Receive' mode or connected to the same Wi-Fi.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(discoveredDevices) { device ->
                    DeviceCard(
                        device = device,
                        onClick = { viewModel.startSendingTo(device) }
                    )
                }
            }

            // Alternative Connection: Manual IP and QR
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Other Ways to Connect",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showManualIpDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("manual_ip_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AddLink, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Enter IP")
                    }

                    OutlinedButton(
                        onClick = { showQrDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("scan_qr_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Connect QR")
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Manual IP Dialog
    if (showManualIpDialog) {
        AlertDialog(
            onDismissRequest = { showManualIpDialog = false },
            title = { Text("Connect to Device IP", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = "Enter the local IP address shown on the receiver device:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = manualIpText,
                        onValueChange = { manualIpText = it },
                        label = { Text("IP Address (e.g. 192.168.1.50)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("manual_ip_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = manualPortText,
                        onValueChange = { manualPortText = it },
                        label = { Text("Port") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("manual_port_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val port = manualPortText.toIntOrNull() ?: 8765
                        if (manualIpText.isNotBlank()) {
                            viewModel.addManualDevice(manualIpText.trim(), port)
                            showManualIpDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaidCyan),
                    modifier = Modifier.testTag("submit_manual_ip_btn")
                ) {
                    Text("Connect", color = Color(0xFF042F2E), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualIpDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // QR Code / URL connection dialog
    if (showQrDialog) {
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            title = { Text("Quick Connect with QR / URL", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = "Enter or paste the receiver's connection URL or scan content (e.g. http://192.168.1.50:8765):",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = qrContentText,
                        onValueChange = { qrContentText = it },
                        label = { Text("URL or IP Address") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("qr_content_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clean = qrContentText.trim()
                            .removePrefix("http://")
                            .removePrefix("https://")
                            .substringBefore("/")
                        val ip = clean.substringBefore(":")
                        val port = clean.substringAfter(":", "8765").toIntOrNull() ?: 8765
                        if (ip.isNotBlank()) {
                            viewModel.addManualDevice(ip, port)
                            showQrDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaidCyan),
                    modifier = Modifier.testTag("submit_qr_connect_btn")
                ) {
                    Text("Connect", color = Color(0xFF042F2E), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQrDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CategoryButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(SaidCyan.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = SaidCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
