package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Electric Cyan & Sky Blue Palette
val SaidCyan = Color(0xFF06B6D4)
val SaidCyanLight = Color(0xFF67E8F9)
val SaidCyanDark = Color(0xFF0891B2)

val SaidSky = Color(0xFF38BDF8)
val SaidSkyLight = Color(0xFFBAE6FD)
val SaidSkyDark = Color(0xFF0284C7)

val SaidEmerald = Color(0xFF10B981)
val SaidEmeraldLight = Color(0xFF6EE7B7)
val SaidEmeraldDark = Color(0xFF059669)

val SaidCoral = Color(0xFFF43F5E)
val SaidAmber = Color(0xFFF59E0B)

// Dark Theme Surfaces
val DarkBg = Color(0xFF0B1120)
val DarkSurface = Color(0xFF151E32)
val DarkCard = Color(0xFF1E293B)
val DarkCardBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Surfaces
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF1F5F9)
val LightCardBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
