package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SaidShareApp
import com.example.data.model.TransferEntity
import com.example.model.DeviceItem
import com.example.model.FileItem
import com.example.model.IncomingRequest
import com.example.model.TransferProgress
import com.example.model.TransferSummary
import com.example.network.NetworkUtils
import com.example.network.SaidHttpServer
import com.example.network.SaidNsdHelper
import com.example.network.SaidTransferClient
import com.example.network.SubnetScanner
import com.example.service.SaidTransferService
import com.example.storage.FileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

enum class AppScreen {
    HOME,
    SEND,
    RECEIVE,
    TRANSFERRING,
    SUCCESS,
    HISTORY,
    SETTINGS
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as SaidShareApp).repository
    private val nsdHelper = SaidNsdHelper(application)
    private val subnetScanner = SubnetScanner()
    private val transferClient = SaidTransferClient(application)
    private val httpServer = SaidHttpServer(application, viewModelScope)

    private val prefs = application.getSharedPreferences("said_share_prefs", Context.MODE_PRIVATE)

    // Current Screen
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Device & Network info
    private val _deviceName = MutableStateFlow(prefs.getString("device_name", null) ?: getDefaultDeviceName())
    val deviceName: StateFlow<String> = _deviceName.asStateFlow()

    private val _localIp = MutableStateFlow(NetworkUtils.getLocalIpAddress(application))
    val localIp: StateFlow<String> = _localIp.asStateFlow()

    private val _isWifiConnected = MutableStateFlow(NetworkUtils.isWifiConnected(application))
    val isWifiConnected: StateFlow<Boolean> = _isWifiConnected.asStateFlow()

    val pin = httpServer.pin
    val serverPort = 8765

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _autoAccept = MutableStateFlow(prefs.getBoolean("auto_accept", false))
    val autoAccept: StateFlow<Boolean> = _autoAccept.asStateFlow()

    private val _keepScreenAwake = MutableStateFlow(prefs.getBoolean("keep_awake", true))
    val keepScreenAwake: StateFlow<Boolean> = _keepScreenAwake.asStateFlow()

    // Dark Mode: null = system, true = dark, false = light
    private val _darkMode = MutableStateFlow<Boolean?>(
        if (prefs.contains("dark_mode")) prefs.getBoolean("dark_mode", false) else null
    )
    val darkMode: StateFlow<Boolean?> = _darkMode.asStateFlow()

    // Selected files for sending
    private val _selectedFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val selectedFiles: StateFlow<List<FileItem>> = _selectedFiles.asStateFlow()

    // Discovered Devices
    private val deviceMap = ConcurrentHashMap<String, DeviceItem>()
    private val _discoveredDevices = MutableStateFlow<List<DeviceItem>>(emptyList())
    val discoveredDevices: StateFlow<List<DeviceItem>> = _discoveredDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    // Active Transfer & Requests
    private val _activeProgress = MutableStateFlow<TransferProgress?>(null)
    val activeProgress: StateFlow<TransferProgress?> = _activeProgress.asStateFlow()

    private val _transferSummary = MutableStateFlow<TransferSummary?>(null)
    val transferSummary: StateFlow<TransferSummary?> = _transferSummary.asStateFlow()

    private val _incomingRequest = MutableStateFlow<IncomingRequest?>(null)
    val incomingRequest: StateFlow<IncomingRequest?> = _incomingRequest.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // History flows from Room
    val allTransfers = repository.allTransfers.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val recentTransfers = repository.recentTransfers.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val sentCount = repository.sentCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    val receivedCount = repository.receivedCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    private var activeTransferJob: Job? = null

    init {
        refreshNetworkState()
        setupHttpServerCallbacks()
        setupNsdCallbacks()
    }

    private fun getDefaultDeviceName(): String {
        val model = Build.MODEL
        val manufacturer = Build.MANUFACTURER
        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "${manufacturer.replaceFirstChar { it.uppercase() }} $model"
        }.take(24)
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun refreshNetworkState() {
        val app = getApplication<Application>()
        _localIp.value = NetworkUtils.getLocalIpAddress(app)
        _isWifiConnected.value = NetworkUtils.isWifiConnected(app)
    }

    fun setDeviceName(newName: String) {
        val trimmed = newName.trim().ifEmpty { getDefaultDeviceName() }
        _deviceName.value = trimmed
        httpServer.deviceName = trimmed
        prefs.edit().putString("device_name", trimmed).apply()
    }

    fun setAutoAccept(enabled: Boolean) {
        _autoAccept.value = enabled
        httpServer.autoAccept = enabled
        prefs.edit().putBoolean("auto_accept", enabled).apply()
    }

    fun setKeepScreenAwake(enabled: Boolean) {
        _keepScreenAwake.value = enabled
        prefs.edit().putBoolean("keep_awake", enabled).apply()
    }

    fun setDarkMode(mode: Boolean?) {
        _darkMode.value = mode
        if (mode == null) {
            prefs.edit().remove("dark_mode").apply()
        } else {
            prefs.edit().putBoolean("dark_mode", mode).apply()
        }
    }

    fun addFiles(uris: List<Uri>) {
        val app = getApplication<Application>()
        val currentList = _selectedFiles.value.toMutableList()
        uris.forEach { uri ->
            val item = FileManager.getFileItemFromUri(app, uri)
            // Prevent duplicates
            if (currentList.none { it.uri == uri || (it.name == item.name && it.size == item.size) }) {
                currentList.add(item)
            }
        }
        _selectedFiles.value = currentList
        // Host files in server for download tab
        httpServer.hostedFiles.clear()
        currentList.forEach { httpServer.hostedFiles[it.name] = it }
    }

    fun removeFile(item: FileItem) {
        val currentList = _selectedFiles.value.toMutableList()
        currentList.removeAll { it.id == item.id }
        _selectedFiles.value = currentList
        httpServer.hostedFiles.remove(item.name)
    }

    fun clearSelectedFiles() {
        _selectedFiles.value = emptyList()
        httpServer.hostedFiles.clear()
    }

    // --- Device Discovery ---

    private fun setupNsdCallbacks() {
        nsdHelper.onDeviceFound = { device ->
            if (device.ip != _localIp.value) {
                deviceMap[device.id] = device
                _discoveredDevices.value = deviceMap.values.toList()
            }
        }
        nsdHelper.onDeviceLost = { serviceName ->
            deviceMap.values.find { it.name == serviceName }?.let {
                deviceMap.remove(it.id)
                _discoveredDevices.value = deviceMap.values.toList()
            }
        }
    }

    fun startDiscovery() {
        refreshNetworkState()
        deviceMap.clear()
        _discoveredDevices.value = emptyList()
        _isScanning.value = true

        nsdHelper.startDiscovery()
        subnetScanner.startScan(
            scope = viewModelScope,
            localIp = _localIp.value,
            port = serverPort
        ) { device ->
            deviceMap[device.id] = device
            _discoveredDevices.value = deviceMap.values.toList()
        }
    }

    fun stopDiscovery() {
        nsdHelper.stopDiscovery()
        subnetScanner.stopScan()
        _isScanning.value = false
    }

    fun addManualDevice(ip: String, port: Int = 8765) {
        val cleanIp = ip.trim()
        val device = DeviceItem(
            id = "$cleanIp:$port",
            name = "Device ($cleanIp)",
            ip = cleanIp,
            port = port,
            deviceType = "pc"
        )
        deviceMap[device.id] = device
        _discoveredDevices.value = deviceMap.values.toList()
    }

    // --- Receive Server Lifecycle ---

    fun startReceiving() {
        refreshNetworkState()
        httpServer.deviceName = _deviceName.value
        httpServer.autoAccept = _autoAccept.value
        val started = httpServer.start(serverPort)
        _isServerRunning.value = started

        if (started) {
            nsdHelper.registerService(
                deviceName = _deviceName.value,
                port = serverPort,
                token = httpServer.sessionToken
            )
            SaidTransferService.startService(
                getApplication(),
                "Ready to receive on ${_localIp.value}:$serverPort"
            )
        }
    }

    fun stopReceiving() {
        httpServer.stop()
        nsdHelper.unregisterService()
        _isServerRunning.value = false
        SaidTransferService.stopService(getApplication())
    }

    private fun setupHttpServerCallbacks() {
        httpServer.onIncomingRequest = { req ->
            _incomingRequest.value = req
        }

        httpServer.onReceiveProgress = { progress ->
            _activeProgress.value = progress
            if (_currentScreen.value != AppScreen.TRANSFERRING) {
                _currentScreen.value = AppScreen.TRANSFERRING
            }
            SaidTransferService.updateProgress(
                getApplication(),
                "Receiving ${progress.currentFileName}",
                (progress.overallPercent * 100).toInt()
            )
        }

        httpServer.onReceiveCompleted = { savedFiles ->
            val totalBytes = savedFiles.sumOf { it.length() }
            val summary = TransferSummary(
                totalFiles = savedFiles.size,
                totalBytes = totalBytes,
                avgSpeedBytesPerSec = 0.0,
                durationMillis = 0L,
                direction = "RECEIVE",
                remoteDeviceName = "Sender",
                savedPaths = savedFiles.map { it.absolutePath }
            )
            _transferSummary.value = summary
            _activeProgress.value = null
            _currentScreen.value = AppScreen.SUCCESS

            // Save in Room database
            viewModelScope.launch(Dispatchers.IO) {
                savedFiles.forEach { f ->
                    repository.recordTransfer(
                        TransferEntity(
                            fileName = f.name,
                            fileSize = f.length(),
                            fileCount = savedFiles.size,
                            direction = "RECEIVED",
                            remoteDeviceName = "Sender",
                            status = "COMPLETED",
                            localPath = f.absolutePath
                        )
                    )
                }
            }

            SaidTransferService.updateProgress(
                getApplication(),
                "Received ${savedFiles.size} files successfully",
                100
            )
        }
    }

    fun acceptIncomingRequest() {
        val req = _incomingRequest.value ?: return
        httpServer.respondToRequest(req.requestId, true)
        _incomingRequest.value = null
        _currentScreen.value = AppScreen.TRANSFERRING
    }

    fun rejectIncomingRequest() {
        val req = _incomingRequest.value ?: return
        httpServer.respondToRequest(req.requestId, false)
        _incomingRequest.value = null
    }

    // --- Sending Files ---

    fun startSendingTo(device: DeviceItem) {
        val files = _selectedFiles.value
        if (files.isEmpty()) {
            _errorMessage.value = "Please select at least one file to send."
            return
        }

        _errorMessage.value = null
        _currentScreen.value = AppScreen.TRANSFERRING
        SaidTransferService.startService(getApplication(), "Connecting to ${device.name}...")

        activeTransferJob?.cancel()
        activeTransferJob = viewModelScope.launch {
            // Handshake
            val handshakeRes = transferClient.sendHandshake(
                device = device,
                senderDeviceName = _deviceName.value,
                files = files
            )

            if (handshakeRes.isFailure) {
                val err = handshakeRes.exceptionOrNull()?.message ?: "Transfer request failed"
                _errorMessage.value = err
                _activeProgress.value = TransferProgress(
                    direction = "SEND",
                    errorMessage = err,
                    remoteDeviceName = device.name
                )
                SaidTransferService.stopService(getApplication())
                return@launch
            }

            // Begin transfer
            val transferRes = transferClient.transferFiles(device, files) { progress ->
                _activeProgress.value = progress
                SaidTransferService.updateProgress(
                    getApplication(),
                    "Sending ${progress.currentFileName} (${(progress.overallPercent * 100).toInt()}%)",
                    (progress.overallPercent * 100).toInt()
                )
            }

            if (transferRes.isSuccess) {
                val summary = transferRes.getOrNull()!!
                _transferSummary.value = summary
                _activeProgress.value = null
                _currentScreen.value = AppScreen.SUCCESS

                // Record each in Room
                withContext(Dispatchers.IO) {
                    files.forEach { file ->
                        repository.recordTransfer(
                            TransferEntity(
                                fileName = file.name,
                                fileSize = file.size,
                                fileCount = files.size,
                                direction = "SENT",
                                remoteDeviceName = device.name,
                                status = "COMPLETED",
                                localPath = null
                            )
                        )
                    }
                }
                SaidTransferService.updateProgress(
                    getApplication(),
                    "Sent ${files.size} files successfully",
                    100
                )
            } else {
                val err = transferRes.exceptionOrNull()?.message ?: "Transfer failed"
                _errorMessage.value = err
                _activeProgress.value = TransferProgress(
                    direction = "SEND",
                    errorMessage = err,
                    remoteDeviceName = device.name
                )
                withContext(Dispatchers.IO) {
                    files.forEach { file ->
                        repository.recordTransfer(
                            TransferEntity(
                                fileName = file.name,
                                fileSize = file.size,
                                fileCount = files.size,
                                direction = "SENT",
                                remoteDeviceName = device.name,
                                status = "FAILED"
                            )
                        )
                    }
                }
                SaidTransferService.stopService(getApplication())
            }
        }
    }

    fun pauseTransfer() {
        transferClient.pause()
        _activeProgress.value = _activeProgress.value?.copy(isPaused = true)
    }

    fun resumeTransfer() {
        transferClient.resume()
        _activeProgress.value = _activeProgress.value?.copy(isPaused = false)
    }

    fun cancelTransfer() {
        transferClient.cancel()
        activeTransferJob?.cancel()
        activeTransferJob = null
        _activeProgress.value = null
        _currentScreen.value = AppScreen.HOME
        SaidTransferService.stopService(getApplication())
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun deleteTransfer(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTransfer(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearHistory()
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopReceiving()
        stopDiscovery()
        nsdHelper.destroy()
    }
}
