package com.example

import android.app.Application
import com.example.data.AppDatabase
import com.example.data.repository.TransferRepository

class SaidShareApp : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { TransferRepository(database.transferDao()) }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: SaidShareApp
            private set
    }
}
