package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.network.NetworkUtils
import com.example.storage.FileManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Said Share", appName)
    }

    @Test
    fun `test pin generation format`() {
        val pin = NetworkUtils.generatePin()
        assertEquals(6, pin.length)
        assertNotNull(pin.toIntOrNull())
    }

    @Test
    fun `test file size formatting`() {
        assertEquals("0 B", FileManager.formatFileSize(0))
        assertEquals("1 KB", FileManager.formatFileSize(1024))
        assertEquals("1 MB", FileManager.formatFileSize(1024 * 1024))
        assertEquals("1.5 MB", FileManager.formatFileSize((1.5 * 1024 * 1024).toLong()))
    }
}
